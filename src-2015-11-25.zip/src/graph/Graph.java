package graph;

import java.util.Arrays;
import java.util.BitSet;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang3.NotImplementedException;

public abstract class Graph implements Cloneable {
	//adjacency list
	final int[][] g;
	//NxN weigth matrix
	final int[][] w;

	public Graph(int[][] g, int[][] w) {
		this.g = g;
		this.w = w;
	}

	public Graph(Graph g) {
		this.g = g.g;
		this.w = g.w;
	}

	private static final class LinkIterator implements Iterator<Integer> {
		final int[] links;
		final int[] weights;
		int index;

		public LinkIterator(int[] links, int[] weights) {
			this.links = links;
			this.weights = weights;
			this.index = 0;
		}

		@Override
		public boolean hasNext() {
			for (; index < links.length; index++) {
				if (weights[links[index]] != 0) {
					return true;
				}
			}
			return false;
		}

		@Override
		public Integer next() {
			return links[index++];
		}

	}

	public Iterable<Integer> getLinks(int n) {
		return () -> new LinkIterator(g[n], w[n]);
	}

	public void disableLink(Link l) {
		disableLink(l.s, l.d);
	}

	public Link disableLink(int s, int d) {
		Link r = getLink(s, d);
		setWeight(s, d, 0);
		return r;
	}

	public void enableLink(Link l) {
		setWeight(l.s, l.d, l.w);
	}

	public int[][] getLinks() {
		return g;
	}

	public int[][] getWeights() {
		return w;
	}

	public int getNumOfEdges() {
		return g.length;
	}

	public int countLinks() {
		//#TODO
		return createLinkList().size();
	}

	public Link getLink(int s, int d) {
		return new Link(s, d, w[s][d]);
	}

	public int getWeight(int s, int d) {
		return w[s][d];
	}

	public abstract List<Link> createLinkList();

	public abstract void setWeight(int s, int d, int weight);

	public abstract boolean isDirected();

	public boolean isConnected() {
		BitSet vis = new BitSet(g.length);
		isConnected(0, vis);
		return vis.nextClearBit(0) == g.length;
	}

	private void isConnected(int i, BitSet vis) {
		vis.set(i);
		for (int j : g[i]) {
			if (!vis.get(j) && w[i][j] != 0) {
				isConnected(j, vis);
			}
		}
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < g.length; i++){
			sb.append(i + ": \t");
			for (int j : g[i]){
				sb.append(j + " ");
			}
			sb.append("\n");
		}
		return sb.toString();
	}

	@Override
	public abstract Graph clone();

	@Override
	public boolean equals(Object obj) {
		throw new NotImplementedException("");
	}

	@Override
	public int hashCode() {
		throw new NotImplementedException("");
	}

	public static final class Link {
		public final int s, d, w;

		public Link(int s, int d, int w) {
			this.s = s;
			this.d = d;
			this.w = w;
		}

		@Override
		public int hashCode() {
			return Arrays.hashCode(new int[]{s, d, w});
		}

		@Override
		public boolean equals(Object obj) {
			if (obj == this)
				return true;
			if (!(obj instanceof Link))
				return false;

			final Link other = (Link) obj;
			return s == other.s && d == other.d && w == other.w;
		}

		@Override
		public String toString() {
			return s + " " + d + ": " + w;
		}
	}

}
