package graph;

import java.util.ArrayList;
import java.util.List;

import utils.Utils;

public final class UndirectedGraph extends Graph {

	public UndirectedGraph(int[][] g, int[][] w) {
		super(g, w);
	}

	public UndirectedGraph(Graph g) {
		super(g);
	}

	@Override
	public List<Link> createLinkList() {
		List<Link> l = new ArrayList<>();
		for (int i = g.length; i-- != 0; ) {
			for (int j : g[i]) {
				if (i <= j) {
					l.add(getLink(i, j));
				}
			}
		}

		return l;
	}

	@Override
	public void setWeight(int s, int d, int weight) {
		w[s][d] = weight;
		w[d][s] = weight;
	}

	@Override
	public boolean isDirected() {
		return false;
	}

	@Override
	public Graph clone() {
		final int l = g.length;
		final int[][] ng = new int[l][];
		final int[][] nw = new int[l][];
		for (int i = l; i-- != 0; ) {
			ng[i] = g[i].clone();
			nw[i] = w[i].clone();
		}

		return new UndirectedGraph(ng, nw);
	}

	public static final class Builder {
		private final ArrayList<ArrayList<Link>> g;

		public Builder() {
			this.g = new ArrayList<>();
		}

		public void add(int s, int d, int w) {
			addDirected(s, d, w);
			addDirected(d, s, w);
		}

		public void add(int s, int d) {
			add(s, d, 1);
		}

		public Builder addAll(int[][] a) {
			for (int i = a.length; i-- != 0; ) {
				int[] t = a[i];
				for (int j = t.length; j-- != 0; ) {
					add(i, t[j]);
				}
			}
			return this;
		}

		public Builder addAll(ArrayList<Integer>[] graphH) {
			//#TODO
			addAll(Utils.toMatrix(graphH));
			return this;
		}

		public void addDirected(int s, int d, int w) {
			while (g.size() <= s) {
				g.add(new ArrayList<>());
			}

			g.get(s).add(new Link(s, d, w));
		}
		public void addDirected(int s, int d) {
			addDirected(s, d, 1);
		}

		public Builder addAllDirected(int[][] a) {
			for (int i = a.length; i-- != 0; ) {
				int[] t = a[i];
				for (int j = t.length; j-- != 0; ) {
					addDirected(i, t[j]);
				}
			}
			return this;
		}

		public Builder addAllDirected(ArrayList<Integer>[] graphH) {
			//#TODO
			addAllDirected(Utils.toMatrix(graphH));
			return this;
		}

		private void checkDuplicates() {
			//terminar,
		}

		public Graph create() {
			checkDuplicates();
			int[][] ng = new int[g.size()][];
			int[][] w = new int[g.size()][g.size()];
			for (int i = 0; i != g.size(); i++) {
				ArrayList<Link> t = g.get(i);
				ng[i] = new int[t.size()];
				for (int j = t.size(); j-- != 0; ) {
					final int d = t.get(j).d;
					final int we = t.get(j).w;
					ng[i][j] = d;
					w[i][d] = we;
				}
			}

			return new UndirectedGraph(ng, w);
		}

	}
}