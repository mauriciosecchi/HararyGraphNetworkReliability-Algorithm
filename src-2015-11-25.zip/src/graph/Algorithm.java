package graph;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Queue;

import org.apache.commons.lang3.ArrayUtils;

public class Algorithm {

	public static int[] bfs(Graph g, int vi, int vd) {
		final BitSet vis = new BitSet(g.getNumOfEdges());
		final int[] p = new int[g.getNumOfEdges()];
		final Queue<Integer> q = new LinkedList<>();

		Arrays.fill(p, -1);
		vis.set(vi);
		q.add(vi);

		while (!q.isEmpty()) {
			int v = q.poll();

			if (v == vd)
				break;

			for (int u : g.getLinks(v)) {
				if (vis.get(u))
					continue;
				p[u] = v;
				vis.set(u);
				q.add(u);
			}
		}

		return p;
	}

	public static int[] precedenceToPath(int[] pred, int vi, int vd) {
		if (pred.length < vd)
			return ArrayUtils.EMPTY_INT_ARRAY;

		ArrayList<Integer> r = new ArrayList<>();
		//#TODO tirar valida��o -1
		for( ; vd != vi && vd != -1; vd = pred[vd]) {
			r.add(vd);
		}
		r.add(vi);

		Collections.reverse(r);

		return ArrayUtils.toPrimitive(r.toArray(new Integer[r.size()]));
	}

	public static int[] bfsPath(Graph g, int vi, int vd) {
		return precedenceToPath(bfs(g, vi, vd), vi, vd);
	}

	public static int maxFlow(Graph g, int vi, int vd) {
		final Graph f = g.clone();
		final int[][] p = f.getWeights();

		int maxFlow = 0;
		for (int[] pred; (pred=bfs(f, vi, vd))[vd] != -1;) {
			int pathFlow = Integer.MAX_VALUE;
			for (int  v=vd; v != vi; v=pred[v]) {
				pathFlow = Math.min(pathFlow, p[pred[v]][v]);
	        }

	        for (int v=vd; v != vi; v=pred[v]) {
	            p[pred[v]][v] -= pathFlow;
	            p[v][pred[v]] += pathFlow;
	        }

	        maxFlow += pathFlow;
		}

		return maxFlow;
	}

	public static int minCut(Graph g) {
		int totalFlow = Integer.MAX_VALUE;

		for (int i = g.getNumOfEdges() - 1; i-- != 0; ) {
			for (int j = i + 1; j < g.getNumOfEdges(); j++) {
				int maxFlow = maxFlow(g, i, j);
				totalFlow = Math.min(totalFlow, maxFlow);
			}
		}

		return totalFlow;
	}
}
