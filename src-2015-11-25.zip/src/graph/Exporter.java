package graph;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.imageio.ImageIO;
import javax.xml.bind.DatatypeConverter;

import org.apache.commons.collections15.functors.ConstantTransformer;
import org.apache.commons.lang3.NotImplementedException;

import edu.uci.ics.jung.algorithms.layout.KKLayout;
import edu.uci.ics.jung.graph.Graph;
import edu.uci.ics.jung.graph.UndirectedSparseGraph;
import edu.uci.ics.jung.visualization.VisualizationImageServer;
import edu.uci.ics.jung.visualization.decorators.ToStringLabeller;
import edu.uci.ics.jung.visualization.renderers.BasicVertexLabelRenderer.InsidePositioner;
import edu.uci.ics.jung.visualization.renderers.Renderer.VertexLabel.Position;

public class Exporter {
	private static Graph<Integer, Integer> convert(graph.Graph g) {
		if (g instanceof UndirectedGraph) {
			Graph<Integer, Integer> jg = new UndirectedSparseGraph<>();
			for (int i = 0; i != g.getNumOfEdges(); i++) {
				jg.addVertex(i);
			}

			int edge = 1;
			for (int i = 0; i != g.getNumOfEdges(); i++) {
				for (int j : g.getLinks(i)) {
					jg.addEdge(edge++, i, j);
				}
			}
			return jg;
		}
		throw new NotImplementedException("");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void toJpeg(graph.Graph g, OutputStream out)
			throws IOException {
		Graph<Integer, Integer> jg = convert(g);

		VisualizationImageServer<Integer, Integer> vv = new VisualizationImageServer<>(
				new KKLayout<Integer, Integer>(jg), new Dimension(600, 600));
		vv.setBackground(Color.white);

		vv.getRenderContext().setEdgeDrawPaintTransformer(
				new ConstantTransformer(Color.lightGray));
		vv.getRenderContext().setArrowFillPaintTransformer(
				new ConstantTransformer(Color.lightGray));
		vv.getRenderContext().setArrowDrawPaintTransformer(
				new ConstantTransformer(Color.lightGray));

		vv.getRenderContext().setVertexLabelTransformer(new ToStringLabeller<>());
		vv.getRenderer().getVertexLabelRenderer()
				.setPositioner(new InsidePositioner());
		vv.getRenderer().getVertexLabelRenderer()
				.setPosition(Position.AUTO);

		Dimension d = vv.getSize();

		BufferedImage bi = new BufferedImage(d.width, d.height,
				BufferedImage.TYPE_INT_BGR);
		Graphics2D graphics = bi.createGraphics();
		graphics.setColor(Color.WHITE);
		graphics.fillRect(0, 0, d.width, d.height);
		vv.paint(graphics);
		graphics.dispose();

		ImageIO.write(bi, "jpeg", out);
	}

	public static String toJpegBase64(graph.Graph g) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		toJpeg(g, out);
		byte[] jpeg = out.toByteArray();
		return DatatypeConverter.printBase64Binary(jpeg);
	}
}
