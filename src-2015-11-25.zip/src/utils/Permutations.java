package utils;
import java.util.Iterator;


public final class Permutations<T> implements Iterable<T[]> {
	private final IndexPermutations idxPerm;
	private final T[] array;
	private final T[] ret;

	public Permutations(T[] array, T[] ret) {
		this.idxPerm = new IndexPermutations(ret.length, array.length);
		this.array = array;
		this.ret = ret;
	}

	private static final class PermIterator<T> implements Iterator<T[]> {
		private final Iterator<int[]> idxPerm;
		private final T[] array;
		private final T[] ret;

		public PermIterator(Iterator<int[]> idxPerm, T[] array, T[] ret) {
			this.idxPerm = idxPerm;
			this.array = array;
			this.ret = ret;
		}

		@Override
		public boolean hasNext() {
			return idxPerm.hasNext();
		}

		@Override
		public T[] next() {
			final int[] idx = idxPerm.next();
			for (int i = idx.length; i-- != 0; ) {
				ret[i] = array[idx[i]];
			}
			return ret;
		}

	}

	@Override
	public Iterator<T[]> iterator() {
		return new PermIterator<>(idxPerm.iterator(), array, ret.clone());
	}

}