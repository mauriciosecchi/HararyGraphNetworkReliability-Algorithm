package utils;
import java.lang.reflect.Array;
import java.math.BigInteger;
import java.util.ArrayList;

import org.apache.commons.lang3.ArrayUtils;


public final class Utils {
	public static int[][] toMatrix(ArrayList<ArrayList<Integer>> a) {
		int[][] m = new int[a.size()][];
		for (int i = a.size(); i-- != 0; ) {
			m[i] = toArray(a.get(i));
		}
		return m;
	}

	public static int[][] toMatrix(ArrayList<Integer>[] a) {
		int[][] m = new int[a.length][];
		for (int i = m.length; i-- != 0; ) {
			m[i] = ArrayUtils.toPrimitive(
					a[i].toArray(new Integer[a[i].size()]));
		}
		return m;
	}

	public static int[] toArray(ArrayList<Integer> a) {
		return ArrayUtils.toPrimitive(
				a.toArray(new Integer[a.size()]));
	}

	//only for warnings
	public static <T> T newArray(Class<?> c, int length) {
		@SuppressWarnings("unchecked")
		T a = (T) Array.newInstance(c, length);
		return a;
	}

	public static BigInteger nextPerm(BigInteger x) {
		//https://en.wikipedia.org/wiki/Combinatorial_number_system#Applications
		final BigInteger u = x.and(x.negate());
		final BigInteger v = u.add(x);
		return v.add(((v.xor(x)).divide(u)).shiftRight(2));
	}

	public static int[] nextPerm(int[] ant) {
		int i;
		for (i = 1; i != ant.length; i++) {
			if (ant[i-1] < ant[i] -1 ) {
				ant[--i]++;
				break;
			}
		}
		if (i == ant.length) {
			ant[--i]++;
		}

		while (i-- != 0) {
			ant[i] = i;
		}

		return ant;
	}
}
