package utils;
import java.util.Iterator;


public final class IndexPermutations implements Iterable<int[]>{
	final int size, max;
	public IndexPermutations(int size, int max) {
		this.size = size;
		this.max = max;
	}

	private static final class PermIterator implements Iterator<int[]> {
		private final int[] perm;
		private final int max0;

		public PermIterator(int size, int max) {
			this.max0 = max - size;
			this.perm = new int[size];
			while (size-- != 0) {
				this.perm[size] = size;
			}
			//para o next retornar corretamente na primeira chamada
			perm[0] = -1;
		}

		@Override
		public boolean hasNext() {
			return perm[0] < max0;
		}

		@Override
		public int[] next() {
			return Utils.nextPerm(perm);
		}

	}

	@Override
	public Iterator<int[]> iterator() {
		return new PermIterator(size, max);
	}
}