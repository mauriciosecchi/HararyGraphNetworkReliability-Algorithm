package main;
import graph.Algorithm;
import graph.DirectedGraph;
import graph.Exporter;
import graph.Graph;
import graph.UndirectedGraph;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import utils.Permutations;
import utils.Utils;

import com.net2plan.interfaces.networkDesign.IReport;
import com.net2plan.interfaces.networkDesign.Net2PlanException;
import com.net2plan.interfaces.networkDesign.NetPlan;
import com.net2plan.utils.Pair;
import com.net2plan.utils.Triple;


public final class HararyGraphNetworkRealibility implements IReport {

	/**
	 * Returns the estimated number of transponders
	 */
	static int getCost(Graph g) {
		int cost = 0;
		Pair<int[], int[]> pathCost;

		for (int i = g.getNumOfEdges() - 1; i-- != 0;) {
			for (int j = i + 1; j < g.getNumOfEdges(); j++) {
				pathCost = getTwoPathBySuurballe(g, i, j);
				cost += (pathCost.getFirst().length * 2 - 2)
						+ (pathCost.getSecond().length * 2 - 2);
			}
		}

		return cost;
	}

	/**
	 * @param g
	 * @param vi start node
	 * @param vd end node
	 */
	static Pair<int[], int[]> getTwoPathBySuurballe(Graph g, int vi, int vd) {
		int[] p1 = Algorithm.bfsPath(g, vi, vd);

		//to keep graph unchanged
		g = g.clone();
		//create a directed graph
		g = new DirectedGraph(g.getLinks(), g.getWeights());

		//remove the directed edges of path
		for (int i = p1.length - 1; i-- != 0; ) {
			g.disableLink(p1[i], p1[i+1]);
		}

		//find the second path, without the first path (p1) edges
		int[] p2 = Algorithm.bfsPath(g, vi, vd);

		//returns if it does not exist two paths
		if (p1.length == 0 || p2.length == 0)
			return null;

		//create a cycle with p1 edges
		ArrayList<Integer>[] aCycle = Utils.newArray(ArrayList.class, g.getNumOfEdges());
		for (int i = aCycle.length; i-- != 0; ) {
			aCycle[i] = new ArrayList<>();
		}

		for (int i = p1.length-1; i-- != 0; ) {
			aCycle[p1[i]].add(p1[i + 1]);
			aCycle[p1[i + 1]].add(p1[i]);
		}

		//add the second path (p2) edges to cycle
		for (int i = p2.length-1; i-- != 0; ) {
			int j, u = p2[i], v = p2[i+1];

			//check if edge is in the cycle
			j = aCycle[u].indexOf(v);
			if (j != -1) {
				aCycle[u].remove(j);//remove(index)
				aCycle[v].remove((Integer)u);//remove(object) (find and remove)
				break;
			} else {//insert
				aCycle[u].add(v);
				aCycle[v].add(u);
			}
		}

		//find a path in cycle, and remove its edges
		int[] a = Algorithm.bfsPath(
				new DirectedGraph.Builder().addAllDirected(aCycle).create(),
				vi, vd);

		for (int i = a.length-1; i-- != 0; ) {
			int u = a[i], v = a[i + 1];
			//remove the path edge
			for (int j = aCycle[u].size(); j-- != 0; ) {
				if (aCycle[u].get(j) == v) {
					for (int k = aCycle[v].size(); k-- != 0; ) {
						if (aCycle[v].get(k) == u) {
							aCycle[v].remove(k);
							break;
						}
					}
					aCycle[u].remove(j);
					break;
				}
			}
		}

		int[] b = Algorithm.bfsPath(
				new DirectedGraph.Builder().addAllDirected(aCycle).create(),
				vi, vd);

		return new Pair<>(a, b, false);
	}

	/**
	 * Build a Harary graph, with <i>n</i> nodes and <i>m</i> edges.
	 * @param n
	 * @param m
	 * @return
	 */
	static Graph algorithmHakimi(int n, int m) {
		ArrayList<Integer>[] graphHarary = Utils.newArray(ArrayList.class, n);
		for (int i = n; i-- != 0; ) {
			graphHarary[i] = new ArrayList<>();
		}

		double q, r;

		q = Math.floor(m / n); //average degree
		r = m - (q * n); //estimates remained edges

		//insert edges in Harary graph
		//iterate over max degree
		for (int p = 1; p <= q; p++) {
			//iterate over edges
			for (int i = 0; i < n - 1; i++) {
				for (int j = i + 1; j < n; j++) {
					if (Math.abs(j - i) <= p || n - Math.abs(j - i) <= p) {
						if (!graphHarary[i].contains(j)) {
							graphHarary[i].add(j);
							graphHarary[j].add(i);
						}
					}
				}
			}
		}

		int s = Math.min((int) r, (n + 1) / 2);

		for (int i = 0; i < s; i++) {
			int j = i + n / 2;
			graphHarary[i].add(j);
			graphHarary[j].add(i);
		}

		//insert other edges randomly
		Random random = new Random();
		if (r > s) {
			int rand1, rand = n - 1;
			for (int i = (int) (r - s); i-- != 0;) {
				while (true) {
					rand1 = random.nextInt(n);
					if (!graphHarary[rand].contains(rand1)) {
						graphHarary[rand].add(rand1);
						graphHarary[rand1].add(rand);
						break;
					}
				}
				rand = random.nextInt(n);
			}
		}

		return new UndirectedGraph.Builder().addAllDirected(graphHarary).create();
	}

	private static final class CutSetsThread extends Thread {
		final Graph g;
		final BlockingQueue<Graph.Link[]> gen;
		public int n = 0;

		public CutSetsThread(Graph g, BlockingQueue<Graph.Link[]> gen) {
			this.g = g;
			this.gen = gen;
		}

		@Override
		public void run() {
			try {
				for (;;) {
					final Graph.Link[] perm = gen.take();
					if (perm.length == 0)
						return;

					//remove selected edges
					for (Graph.Link l : perm) {
						g.disableLink(l);
					}

					if (!g.isConnected()) {
						n++;
					}

					//reinsert removed edges
					for (Graph.Link l : perm) {
						g.enableLink(l);
					}
				}
			} catch (InterruptedException e) {
				throw new AssertionError(e);
			}
		}

	}

	private static final class PermGenThread extends Thread {
		private final BlockingQueue<Graph.Link[]>[] perms;
		private final Permutations<Graph.Link> perm;

		public PermGenThread(Graph g, int size, BlockingQueue<Graph.Link[]>[] perms) {
			this.perms = perms;
			List<Graph.Link> tmp = g.createLinkList();
			Graph.Link[] links = tmp.toArray(new Graph.Link[tmp.size()]);
			this.perm = new Permutations<>(links, new Graph.Link[size]);
		}

		private int minSizeIdx() {
			int minIdx = perms.length - 1;
			int minSize = perms[minIdx].size();
			for (int i = minIdx; i-- != 0; ) {
				final int iSize = perms[i].size();
				if (iSize < minSize) {
					minIdx = i;
					minSize = iSize;
				}
			}
			return minIdx;
		}

		@Override
		public void run() {
			try {
				for(Graph.Link[] l : perm) {
					//threads load balance
					final int thread = minSizeIdx();

					perms[thread].put(l.clone());
				};

				final Graph.Link[] empty = new Graph.Link[0];
				//notify end of permutations
				for (BlockingQueue<Graph.Link[]> l : perms) {
					l.put(empty);
				}
			} catch (InterruptedException e1) {
			}
		}
	}

	/**
	 * Returns the number of distinct sets of links with the specified size,
	 * that disconnects the graph.
	 * @param graph
	 * @param size The size of the sets;
	 */
	static int cutSets(Graph graph, int size) {
		try {
			final int N_THREADS = 8;
			CutSetsThread[] threads = new CutSetsThread[N_THREADS];
			//permutation lists
			BlockingQueue<Graph.Link[]>[] perms = Utils.newArray(BlockingQueue.class, N_THREADS);

			for (int i = N_THREADS; i-- != 0; ) {
				perms[i] = new LinkedBlockingQueue<>(4096);
				threads[i] = new CutSetsThread(graph.clone(), perms[i]);
				threads[i].start();
			}

			//permutation generator
			new PermGenThread(graph, size, perms).start();

			int n = 0;
			for (CutSetsThread t : threads) {
				t.join();
				n += t.n;
			}
			return n;
		} catch (Exception e) {
			throw new AssertionError(e);
		}
	}

	/**
	 * @param p ho
	 * @param S Number of cut sets of size 2, 3 and 4
	 * @param l links number
	 * @param conectivity
	 * @return
	 */
	public static float getNetworkRealibility(double pho, int[] S, int l,
			int conectivity) {
		float networkRealibility = 0;

		for (int i = conectivity; i < conectivity + 2 && i <= 4; i++) {
			networkRealibility += S[i - 2] * Math.pow(pho, i)
					* Math.pow(1. - pho, l - (i));
		}
		return 1 - networkRealibility;
	}

	public static final class CalcThread extends Thread {
		final Graph g;
		final String name;
		final TablePrinter ps;
		final double pho;

		public CalcThread(Graph g, String name, TablePrinter sb, double pho) {
			this.g = g;
			this.name = name;
			this.ps = sb;
			this.pho = pho;
		}

		@Override
		public void run() {
			ps.printLine("Graph", name);
			//minimum cut
			int cut = Algorithm.minCut(g);
			synchronized (ps) {
				ps.printLine("Minimum cut set:", cut);
			}

			//transponders number
			int cost = getCost(g);
			synchronized (ps) {
				ps.printLine("Transponders number:", cost);
			}

			//long time = System.currentTimeMillis();
			int[] S = new int[3];
			S[0] = cutSets(g, 2);
			S[1] = cutSets(g, 3);
			S[2] = cutSets(g, 4);
			//System.out.println("Time = " + (System.currentTimeMillis() - time));

			float conf = getNetworkRealibility(pho, S, g.countLinks(), cut);
			synchronized (ps) {
				ps.printLine("Cut Sets (2)", S[0]);
				ps.printLine("Cut Sets (3)", S[1]);
				ps.printLine("Cut Sets (4)", S[2]);
				ps.printLine("Graph realibility", conf);
				ps.end();
			}
		}
	}

	public static Graph execute(Graph g, TablePrinter pInput, TablePrinter pHarary, double pho) {
		int n, m;

		n = g.getNumOfEdges();
		m = g.countLinks();

		if ((2 * m) / n < 3){
			throw new Net2PlanException("The graph needs to have a average degree greater or equal to 3.");
		}

		//generate a Harary graph, with n nodes and m edges
		Graph gHarary = algorithmHakimi(n, m);

		//min cut of original graph
		int cut = Algorithm.minCut(g);

		if (cut > 1){
			Thread tE = new CalcThread(g, "Input", pInput, pho);
			Thread tH = new CalcThread(gHarary, "Harary", pHarary, pho);

			tE.start();
			tH.start();

			try {
				tE.join();
				tH.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		}

		return gHarary;
	}

	private interface TablePrinter {
		public void printHeader(String def, String value);
		public void printLine(String def, String value);
		public default void end() {}
		public default void printLine(String def, Object value) {
			printLine(def, String.valueOf(value));
		}
	}

	private class HtmlTablePrinter implements TablePrinter {
		final StringBuilder sb;

		public HtmlTablePrinter() {
			sb = new StringBuilder("<table border=\"1\">");
		}

		@Override
		public void printHeader(String def, String value) {
			sb.append("<tr><td><b>");
			sb.append(def);
			sb.append("</b></td><td><b>");
			sb.append(value);
			sb.append("</b></td></tr>");
		}

		@Override
		public void printLine(String def, String value) {
			sb.append("<tr><td>");
			sb.append(def);
			sb.append("</td><td>");
			sb.append(value);
			sb.append("</td></tr>");
		}


		@Override
		public void end() {
			sb.append("</table>");
		}

		@Override
		public String toString() {
			return sb.toString();
		}
	}

	@Override
	public String executeReport(NetPlan netPlan, Map<String, String> algParams,
			Map<String, String> net2PlanParams) {
		UndirectedGraph.Builder b = new UndirectedGraph.Builder();

		Map<Long, Pair<Long, Long>> map = netPlan.getLinkMap();
		for (Long l : map.keySet()) {
			final Pair<Long, Long> a = map.get(l);
			b.addDirected(a.getFirst().intValue(), a.getSecond().intValue());
		}

		double pho = Double.parseDouble(algParams.get("pho"));
		if (pho <= 0. || pho >= 1.) {
			throw new Net2PlanException("pho should be between 0 and 1");
		}


		final StringBuilder sb = new StringBuilder();
		sb.append("<html><head></head><body><table><tr><td>");

		final HtmlTablePrinter input = new HtmlTablePrinter();
		final HtmlTablePrinter harary = new HtmlTablePrinter();
		Graph h = execute(b.create(), input, harary, pho);

		sb.append(input.toString());
		sb.append("</td><td>");
		sb.append(harary.toString());

		sb.append("</td></tr><tr><td colspan=\"2\">");

		String path = new File(".").getAbsolutePath();

		try(OutputStream out = new FileOutputStream(path + "/img.jpg")) {
			Exporter.toJpeg(h, out);
		} catch (IOException e) {
			throw new Net2PlanException(e.getMessage());
		}

		sb.append("<br/>");
		sb.append("<img alt=\"Graph Image\" src=\"file:/" + path + "/img.jpg\"/>");
		sb.append("</td></tr></body></html>");

		return sb.toString();
	}

	@Override
	public String getDescription() {
		return "The algorithm maximizes the network reliability without change his base structure, "
				+ "i.e, it keeps the same node and links number. It redistribute the links and looks for higher level"
				+ " of reliability using a subclass of Hararys graph."
				+ " This algorithm calculates the reliability of the user network and for the new graph generated"
				+ " using the Hararys subclass graph, when the average degree is greater than 2. Posteriorly, a comparison "
				+ "between the networks is realized. Furthermore, the cutting set of both graphs with their cost is compared."
				+ ""
				+ "\nAutors: Emerson Dallagnol, Mauricio Secchi, Roberto Walter."
				+ "\nUniversidade Federal da Fronteira Sul";
	}

	@Override
	public List<Triple<String, String, String>> getParameters() {
		List<Triple<String, String, String>> l = new ArrayList<>();
		l.add(new Triple<>("pho", "0.05", "The probability of a link rupture.", false));
		return l;
	}

	public static void main(String[] args) throws FileNotFoundException {
		System.out.println(args[0]);
		for (File f : new File(args[0]).listFiles()) {
			UndirectedGraph.Builder b = new UndirectedGraph.Builder();

			System.out.println(f.getName());
			try {
				Scanner s = new Scanner(new BufferedInputStream(new FileInputStream(f)));

				try {
					while (s.hasNextInt()) {
						int u, v;
						u = s.nextInt() - 1;
						v = s.nextInt() - 1;

						b.add(u, v);
					}
				} finally {
					s.close();
				}

				TablePrinter tp = new TablePrinter() {
					@Override
					public void printLine(String def, String value) {
						System.out.println("Harary: " + def + " - " + value);
					}

					@Override
					public void printHeader(String def, String value) {
						printLine(def, value);
					}
				};

				Graph h = execute(b.create(), tp, tp, 0.05);

				String graphImg;
				try {
					graphImg = Exporter.toJpegBase64(h);
				} catch (IOException e) {
					throw new Net2PlanException(e.getMessage());
				}
				System.out.println("base64 img=data:image/jpg;base64," + graphImg);
			} catch (Net2PlanException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
				e.printStackTrace();
			}

			System.out.println();
			System.out.println();
		}
	}


	@Override
	public String getTitle() {
		return "Realibility using a Harary graph.";
	}
}